package com.example.miaplicacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignIn extends AppCompatActivity {
    private EditText email, password;

    private FirebaseAuth myAuth;


    final static String LOG_TAG = "MCS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        myAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.signInEmail);
        password = findViewById(R.id.signInPassword);

    }

    public void signIn(View view) {

        String emailString = email.getText().toString();
        String passwordString = password.getText().toString();
        if (!emailString.isEmpty() && !passwordString.isEmpty()) {
            myAuth.createUserWithEmailAndPassword(emailString, passwordString)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                //(Sign in success, update UI with the signed-in user's information
                                Log.d(LOG_TAG, "createUserWithEmail: success");
                                FirebaseUser user = myAuth.getCurrentUser();
                                Toast.makeText(SignIn.this, "Has creado tu cuenta correctamente", Toast.LENGTH_LONG).show();
                                Intent siguiente = new Intent(SignIn.this, Inicio.class);
                                startActivity(siguiente);

                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(LOG_TAG, "createUserWithEmail:failure", task.getException());
                                Toast.makeText(SignIn.this, "Vaya... Algo ha ido mal", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        } else {
            Toast.makeText(SignIn.this, "Vaya... Algo ha ido mal", Toast.LENGTH_LONG).show();
        }



    }

}