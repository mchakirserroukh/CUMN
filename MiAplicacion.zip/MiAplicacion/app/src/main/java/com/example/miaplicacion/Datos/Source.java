package com.example.miaplicacion.Datos;

import java.io.Serializable;

public class Source implements Serializable {

    /*
    hemos sacado nuestro json al igual que en el resto y sus atributos mirael resto de clases de este package
    esta sin mas
    */

    String id="";
    String name="";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
