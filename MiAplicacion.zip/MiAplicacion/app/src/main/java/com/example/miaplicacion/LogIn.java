package com.example.miaplicacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;


import android.os.Bundle;
import android.util.Log;
import android.view.View;


import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class LogIn extends AppCompatActivity {

    private EditText email,password;

    private FirebaseAuth myAuth;


    final static String LOG_TAG = "MCS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        myAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.logInEmail);
        password = findViewById(R.id.logInPassword);
    }

    public void logIn(View view) {

            String emailString = email.getText().toString();
            String passwordString = password.getText().toString();
        if (!emailString.isEmpty() && !passwordString.isEmpty()) {
            myAuth.signInWithEmailAndPassword(emailString, passwordString)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Log.d(LOG_TAG, "sigInWithEmail:succes");
                                Toast.makeText(LogIn.this, "Has iniciado sesión correctamente", Toast.LENGTH_LONG).show();
                                //guardarDatos(emailString, passwordString);
                                //Aqui tengo que hacer algo mass
                                Intent siguiente = new Intent(LogIn.this, Inicio.class);
                                startActivity(siguiente);


                            } else {
                                Log.w(LOG_TAG, "signInWithEmail:failure", task.getException());
                                Toast.makeText(LogIn.this, "Vaya... Algo ha ido mal", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

        }else{
            Toast.makeText(LogIn.this, "Vaya... Algo ha ido mal", Toast.LENGTH_LONG).show();
        }




    }




}


