package com.example.miaplicacion;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class NewsViewHolder extends RecyclerView.ViewHolder{

    /*
    sacar los elemntos de nuestro item_list que serian las imagenes y los textos textview osea de los items ojooooooo
    Solo sacae se hacen aqui
    */
    TextView titulo, source;
    ImageView imagenTitular;
    //Añadir tambien cardview
    CardView cardView;

    public NewsViewHolder(@NonNull View itemView) {
        super(itemView);
        titulo=itemView.findViewById(R.id.titulo);
        source= itemView.findViewById(R.id.source);
        imagenTitular=itemView.findViewById(R.id.imagenTitular);

        //esto es un container que es dond esta metido si miras en item_list...
        cardView= itemView.findViewById(R.id.containerInicio);
    }
}
