package com.example.miaplicacion.Datos;

import java.io.Serializable;
import java.util.List;

public class NoticiasResponse implements Serializable {

    /*
    hemos sacado nuestro json al igual que en el resto y sus atributos mirael resto de clases de este package
    Aqui en este caso sacamos segun la api toooodso los atributos json osea esta clase tiene todas las otras clases
    */

    String status;
    int totalResults;
    List<Articles> articles;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public List<Articles> getArticles() {
        return articles;
    }

    public void setArticles(List<Articles> articles) {
        this.articles = articles;
    }
}
