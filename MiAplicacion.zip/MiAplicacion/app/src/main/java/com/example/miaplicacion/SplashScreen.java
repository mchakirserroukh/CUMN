package com.example.miaplicacion;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;


@SuppressLint("CustomSplashScreen")
public class  SplashScreen extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTheme(R.style.SplashTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
    }


    public void crearCuenta(View view){
        Intent signIn = new Intent(this,SignIn.class);
        startActivity(signIn);

    }
    public void iniciarSesion(View view){
        Intent logIn = new Intent(this,LogIn.class);
        startActivity(logIn);

    }




}