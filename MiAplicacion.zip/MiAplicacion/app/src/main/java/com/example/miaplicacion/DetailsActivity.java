package com.example.miaplicacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;


import android.os.Bundle;


import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.miaplicacion.Datos.Articles;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


public class DetailsActivity extends AppCompatActivity {
    Articles articles;
    TextView txtTitle, txtAuthor, txtTime, txtDetail, txtContent;
    ImageView imgNews;
    TextView numLikes, numVisitas;
    DatabaseReference newsRef = FirebaseDatabase.getInstance().getReference().child("news");
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    Integer numVisitasInteger, numVisitasIntegerDeUser, numLikesInteger, numLikesIntegerDeUser;


    CheckBox checkBox;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        numLikes = findViewById(R.id.numLikes);
        numVisitas = findViewById(R.id.numVisitas);
        checkBox = findViewById(R.id.checkBox);
        txtTitle = findViewById(R.id.text_detail_title);
        txtDetail = findViewById(R.id.text_detail_detail);
        txtAuthor = findViewById(R.id.text_detail_author);
        txtTime = findViewById(R.id.text_detail_time);
        txtContent = findViewById(R.id.text_detail_content);
        imgNews = findViewById(R.id.img_detail_news);


        articles = (Articles) getIntent().getSerializableExtra("data");

        txtTitle.setText(articles.getTitle());
        txtAuthor.setText(articles.getAuthor());
        txtDetail.setText(articles.getDescription());
        txtContent.setText(articles.getContent());
        txtTime.setText(articles.getPublishedAt());
        Picasso.get().load(articles.getUrlToImage()).into(imgNews);


        aniadirVisitas();


        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    aniadirLikes();
                } else {
                    disminuirLikes();
                }
            }
        });


    }

    private void aniadirVisitas() {
        String cadenaSinCaracteres = eliminarEspaciosYCaracteresEspeciales(txtTitle.getText().toString());

        newsRef.child(cadenaSinCaracteres).child("visitas").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                numVisitasInteger = snapshot.getValue(Integer.class);
                if (numVisitasInteger != null) {
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("visitas").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            numVisitasIntegerDeUser = snapshot.getValue(Integer.class);
                            if (numVisitasIntegerDeUser != null) {
                                if (numVisitasIntegerDeUser != 1) {
                                    numVisitasInteger++;
                                    newsRef.child(cadenaSinCaracteres).child("visitas").setValue(numVisitasInteger);
                                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("visitas").setValue(1);
                                    numVisitas.setText(String.valueOf(numVisitasInteger));
                                } else {
                                    numVisitas.setText(String.valueOf(numVisitasInteger));
                                    Toast.makeText(DetailsActivity.this, "Ya has visto esta noticia", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("visitas").setValue(1);
                                numVisitasInteger++;
                                numVisitas.setText(String.valueOf(numVisitasInteger));
                                newsRef.child(cadenaSinCaracteres).child("visitas").setValue(numVisitasInteger);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(DetailsActivity.this, "Error", Toast.LENGTH_SHORT).show();
                        }
                    });

                } else {
                    newsRef.child(cadenaSinCaracteres).child("visitas").setValue(1);
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("visitas").setValue(1);
                    numVisitas.setText(String.valueOf(1));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(DetailsActivity.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static String eliminarEspaciosYCaracteresEspeciales(String cadena) {
        String cadenaSinEspacios = cadena.replaceAll("\\s", "");
        return cadenaSinEspacios.replaceAll("[^a-zA-Z0-9]", "");
    }

    private void aniadirLikes() {
        String cadenaSinCaracteres = eliminarEspaciosYCaracteresEspeciales(txtTitle.getText().toString());

        newsRef.child(cadenaSinCaracteres).child("likes").addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                numLikesInteger = snapshot.getValue(Integer.class);
                if (numLikesInteger != null) {
                    numLikes.setText(String.valueOf(numLikesInteger));
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            numLikesIntegerDeUser = snapshot.getValue(Integer.class);
                            if (numLikesIntegerDeUser != null) {
                                if (numLikesIntegerDeUser != 1) {
                                    numLikesInteger++;
                                    newsRef.child(cadenaSinCaracteres).child("likes").setValue(numLikesInteger);
                                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(1);
                                    numLikes.setText(String.valueOf(numLikesInteger));


                                } else {
                                    numLikes.setText(String.valueOf(numLikesInteger));
                                    Toast.makeText(DetailsActivity.this, "Ya habías dado like", Toast.LENGTH_SHORT).show();
                                }

                            } else {
                                newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(1);
                                numLikesInteger++;
                                numLikes.setText(String.valueOf(numLikesInteger));
                                newsRef.child(cadenaSinCaracteres).child("likes").setValue(numLikesInteger);

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                } else {
                    newsRef.child(cadenaSinCaracteres).child("likes").setValue(1);
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(1);
                    numLikes.setText(String.valueOf(1));


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void disminuirLikes() {
        String cadenaSinCaracteres = eliminarEspaciosYCaracteresEspeciales(txtTitle.getText().toString());

        newsRef.child(cadenaSinCaracteres).child("likes").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                numLikesInteger = snapshot.getValue(Integer.class);
                if (numLikesInteger != null) {
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            numLikesIntegerDeUser = snapshot.getValue(Integer.class);
                            if (numLikesIntegerDeUser != null) {
                                if (numLikesIntegerDeUser == 1) {
                                    numLikesInteger--;
                                    newsRef.child(cadenaSinCaracteres).child("likes").setValue(numLikesInteger);
                                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(0);
                                    numLikes.setText(String.valueOf(numLikesInteger));
                                } else {
                                    newsRef.child(cadenaSinCaracteres).child("likes").setValue(numLikesInteger);
                                    numLikes.setText(String.valueOf(numLikesInteger));
                                    Toast.makeText(DetailsActivity.this, "Ya habías dado dislike", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(0);
                                Toast.makeText(DetailsActivity.this, "error", Toast.LENGTH_SHORT).show();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                } else {
                    newsRef.child(cadenaSinCaracteres).child("likes").setValue(0);
                    newsRef.child(cadenaSinCaracteres).child(user.getUid()).child("likes").setValue(0);
                    numLikes.setText(String.valueOf(0));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

}