package com.example.miaplicacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.miaplicacion.Datos.Articles;
import com.example.miaplicacion.Datos.NoticiasResponse;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;


public class Inicio extends AppCompatActivity implements ArticleListener {
    RecyclerView recyclerView;
    NewsAdapter adapter;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        NewsRequest newsRequest = new NewsRequest(this);

        newsRequest.getNewsArticles(listener, "general", null);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        NewsRequest newsRequest;
        switch (item.getItemId()) {
            case R.id.businessOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "business", null);
                break;
            case R.id.generalOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "general", null);
                break;
            case R.id.entertainmentOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "entertainment", null);
                break;
            case R.id.healthOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "health", null);
                break;
            case R.id.scienseOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "science", null);
                break;
            case R.id.sportsOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "sport", null);
                break;
            case R.id.technologyOption:
                newsRequest = new NewsRequest(this);
                newsRequest.getNewsArticles(listener, "technology", null);
                break;
            case R.id.cerrarSesion:
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, SplashScreen.class));
                break;

        }
        return super.onContextItemSelected(item);
    }


    private final Listener<NoticiasResponse> listener = new Listener<NoticiasResponse>() {
        @Override
        public void onFetchData(List<Articles> list, String message) {
            showNews(list);
        }

        @Override
        public void onError(String message) {

        }
    };

    private void showNews(List<Articles> list) {

        recyclerView = findViewById(R.id.rvInicio);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new NewsAdapter(this, list, this);
        recyclerView.setAdapter(adapter);


    }

    @Override
    public void onNewsClicked(Articles articles) {
        Intent siguiente = new Intent(Inicio.this, DetailsActivity.class).putExtra("data", articles);

        startActivity(siguiente);

    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Salir y cerrar sesión en el menú de arriba", Toast.LENGTH_SHORT).show();
    }
}