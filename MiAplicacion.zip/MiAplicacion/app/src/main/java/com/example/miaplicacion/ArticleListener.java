package com.example.miaplicacion;

import com.example.miaplicacion.Datos.Articles;

public interface ArticleListener {
    void onNewsClicked(Articles articles);
}
