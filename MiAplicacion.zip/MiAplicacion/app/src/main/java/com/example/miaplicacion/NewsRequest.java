package com.example.miaplicacion;

import android.content.Context;
import android.widget.Toast;

import com.example.miaplicacion.Datos.NoticiasResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

public class NewsRequest {



    Context context;
    Retrofit retrofit = new Retrofit.Builder().baseUrl("https://newsapi.org/v2/").addConverterFactory(GsonConverterFactory.create()).build();

    public void getNewsArticles(Listener listener, String category,String query){

        CallNewsApi callNewsApi = retrofit.create(CallNewsApi.class);
        Call<NoticiasResponse> call = callNewsApi.callArticles("us",category,query,context.getString(R.string.api_key));

        try{
            call.enqueue(new Callback<NoticiasResponse>() {
                @Override
                public void onResponse(Call<NoticiasResponse> call, Response<NoticiasResponse> response) {
                    if (!response.isSuccessful()){
                        Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                    }
                    listener.onFetchData(response.body().getArticles(),response.message());
                }

                @Override
                public void onFailure(Call<NoticiasResponse> call, Throwable t) {
                    listener.onError("Ha habido un error");
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }

    }


    public NewsRequest(Context context) {
        this.context = context;
    }


    public interface CallNewsApi{
        @GET("top-headlines")
        Call<NoticiasResponse> callArticles (
                @Query("country") String country,
                @Query("category") String category,
                @Query("q") String query,
                @Query("apiKey") String apiKey
        );

    }
}
