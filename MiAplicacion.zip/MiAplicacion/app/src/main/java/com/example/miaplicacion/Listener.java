package com.example.miaplicacion;

import com.example.miaplicacion.Datos.Articles;

import java.util.List;

public interface Listener <NoticiasResponse>{

    void onFetchData(List<Articles> list, String message);
    void onError(String message);
}
