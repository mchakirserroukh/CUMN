package com.example.miaplicacion;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import androidx.recyclerview.widget.RecyclerView;

import com.example.miaplicacion.Datos.Articles;
import com.squareup.picasso.Picasso;

import java.util.List;



public class NewsAdapter extends RecyclerView.Adapter<NewsViewHolder> {

    private Context context;

    /*
    * Aqui tengo que hacerme una lista de los elementos que me rentan, que en mi caso creo que seria characters.
    * En este caso tenemos una lista provada de articles y no de noticias response ni tampoco de source pq de donde vamos
    * a obtener las cosas va a ser de articles. En el caso de marvel seria de characters creo.
    * Este es el codigo tocho dond adaptamos""
    * */
    private List<Articles> articles;
    private ArticleListener articleListener;


    public NewsAdapter(Context context, List<Articles> articles, ArticleListener articleListener) {
        this.context = context;
        this.articles = articles;
        this.articleListener=articleListener;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NewsViewHolder(LayoutInflater
                .from(context)
                .inflate(R.layout.titular_item, parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        holder.titulo.setText(articles.get(position).getTitle());
        holder.source.setText(articles.get(position).getSource().getName());
        if(articles.get(position).getUrlToImage()!=null){
            Picasso.get().load(articles.get(position).getUrlToImage()).into(holder.imagenTitular);
        }
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                articleListener.onNewsClicked(articles.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return articles.size();
    }
}
